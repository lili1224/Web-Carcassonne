# TecWeb_P-Final
Vamos a organizarnos, yo he sido el primero en cagarla con esto.

Sigamos las instrucciones vale?

Primero ejecuta lo siguiente: 
$ git clone https://github.com/A-vidal/TecWeb_P-Final.git

Ahora tendrás el proyecto en la carpeta TecWeb_P-Final

Para modificar algo, realiza los sigientes pasos:
1. $ git pull
2. modifica lo que haga falta
3. $ git add (archivo)
4. $ git commit -m <mensaje relevante*>
5. avisar al grupo de lo que has hecho
6. $ git push origin main

* mensaje relevante: explica lo que has hacho en una frase (no olvides las comillas " o ')

Para ser conscientes de lo que hacemos utilizad estos comandos:
- $ git status --short
- $ git log --oneline --all --graph
